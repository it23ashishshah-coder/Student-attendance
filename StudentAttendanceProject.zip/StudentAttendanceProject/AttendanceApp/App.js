import React, { useState, useEffect } from 'react';
import {
  View, Text, TextInput, Button, FlatList, StyleSheet,
  ActivityIndicator, TouchableOpacity, SafeAreaView, Alert,
} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

// Android emulator -> 10.0.2.2 | iOS simulator -> localhost | real phone -> your PC's LAN IP
const BASE_URL = 'http://10.0.2.2:3000/api';
const MIN_PERCENT = 75;

const Stack = createNativeStackNavigator();

/* ---------------- 1. LOGIN ---------------- */
function LoginScreen({ navigation, onLogin }) {
  const [studentId, setStudentId] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const [apiError, setApiError] = useState('');

  const validate = () => {
    const e = {};
    if (!studentId.trim()) e.studentId = 'Student ID is required';
    else if (!/^[A-Za-z0-9]{4,12}$/.test(studentId.trim()))
      e.studentId = 'ID must be 4-12 letters/digits';
    if (!password) e.password = 'Password is required';
    else if (password.length < 6) e.password = 'Password must be at least 6 characters';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleLogin = async () => {
    setApiError('');
    if (!validate()) return;
    setLoading(true);
    try {
      const res = await fetch(`${BASE_URL}/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ studentId: studentId.trim(), password }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || 'Login failed');
      onLogin(data.student);
      navigation.replace('Dashboard');
    } catch (err) {
      setApiError(err.message || 'Network error. Is the server running?');
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>Student Attendance</Text>
      <Text style={styles.subtitle}>Login to continue</Text>

      <TextInput
        style={styles.input}
        placeholder="Student ID"
        autoCapitalize="characters"
        value={studentId}
        onChangeText={setStudentId}
      />
      {errors.studentId && <Text style={styles.error}>{errors.studentId}</Text>}

      <TextInput
        style={styles.input}
        placeholder="Password"
        secureTextEntry
        value={password}
        onChangeText={setPassword}
      />
      {errors.password && <Text style={styles.error}>{errors.password}</Text>}

      {apiError !== '' && <Text style={styles.error}>{apiError}</Text>}
      {loading ? <ActivityIndicator size="large" color="#1e88e5" /> : <Button title="Login" onPress={handleLogin} />}
    </SafeAreaView>
  );
}

/* ---------------- 2. DASHBOARD ---------------- */
function DashboardScreen({ navigation, student, onLogout }) {
  const logout = () => { onLogout(); navigation.replace('Login'); };
  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.card}>
        <Text style={styles.heading}>Welcome, {student.name}</Text>
        <Text style={styles.line}>Student ID: {student.studentId}</Text>
        <Text style={styles.line}>Course: {student.course}</Text>
        <Text style={styles.line}>Semester: {student.semester}</Text>
      </View>
      <View style={styles.btn}><Button title="View Attendance" onPress={() => navigation.navigate('Attendance')} /></View>
      <View style={styles.btn}><Button title="My Profile" onPress={() => navigation.navigate('Profile')} /></View>
      <View style={styles.btn}><Button title="Logout" color="#e53935" onPress={logout} /></View>
    </SafeAreaView>
  );
}

/* ---------------- 3-5. ATTENDANCE ---------------- */
const calcPercent = (attended, total) => (total === 0 ? 0 : (attended / total) * 100);

function AttendanceScreen({ student }) {
  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');
  const [reload, setReload] = useState(0);

  // Fetch on mount and whenever "Retry" is pressed
  useEffect(() => {
    let active = true;
    const load = async () => {
      setLoading(true);
      setError('');
      try {
        const res = await fetch(`${BASE_URL}/attendance/${student.studentId}`);
        if (!res.ok) throw new Error(`Server error (${res.status})`);
        const data = await res.json();
        if (active) setRecords(data);
      } catch (err) {
        if (active) setError(err.message || 'Failed to load attendance');
      } finally {
        if (active) setLoading(false);
      }
    };
    load();
    return () => { active = false; };
  }, [reload, student.studentId]);

  const filtered = records.filter(r =>
    r.subject.toLowerCase().includes(search.trim().toLowerCase())
  );

  const totalAttended = records.reduce((s, r) => s + r.attended, 0);
  const totalClasses = records.reduce((s, r) => s + r.total, 0);
  const overall = calcPercent(totalAttended, totalClasses);

  if (loading)
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#1e88e5" />
        <Text style={{ marginTop: 10 }}>Loading attendance...</Text>
      </View>
    );

  if (error)
    return (
      <View style={styles.center}>
        <Text style={styles.error}>Error: {error}</Text>
        <Button title="Retry" onPress={() => setReload(n => n + 1)} />
      </View>
    );

  const renderItem = ({ item }) => {
    const pct = calcPercent(item.attended, item.total);
    const ok = pct >= MIN_PERCENT;
    return (
      <View style={[styles.card, { borderLeftColor: ok ? '#43a047' : '#e53935', borderLeftWidth: 6 }]}>
        <Text style={styles.heading}>{item.subject}</Text>
        <Text style={styles.line}>Attended {item.attended} / {item.total} classes</Text>
        <Text style={styles.line}>Percentage: {pct.toFixed(1)}%</Text>
        <Text style={{ color: ok ? '#2e7d32' : '#c62828', fontWeight: 'bold' }}>
          {ok ? 'Attendance Satisfactory' : 'Attendance Shortage'}
        </Text>
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.summary}>
        <Text style={styles.summaryText}>Overall: {overall.toFixed(1)}%</Text>
        <Text style={{ color: '#fff' }}>
          {overall >= MIN_PERCENT ? 'Attendance Satisfactory' : 'Attendance Shortage'}
        </Text>
      </View>
      <TextInput
        style={styles.input}
        placeholder="Search by subject..."
        value={search}
        onChangeText={setSearch}
      />
      <FlatList
        data={filtered}
        keyExtractor={item => String(item.id)}
        renderItem={renderItem}
        ListEmptyComponent={<Text style={styles.center}>No subjects found.</Text>}
      />
    </SafeAreaView>
  );
}

/* ---------------- PROFILE ---------------- */
function ProfileScreen({ navigation, student, onLogout }) {
  const logout = () => {
    Alert.alert('Logout', 'Are you sure?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Logout', onPress: () => { onLogout(); navigation.replace('Login'); } },
    ]);
  };
  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.card}>
        <Text style={styles.heading}>{student.name}</Text>
        <Text style={styles.line}>Student ID: {student.studentId}</Text>
        <Text style={styles.line}>Email: {student.email}</Text>
        <Text style={styles.line}>Course: {student.course}</Text>
        <Text style={styles.line}>Semester: {student.semester}</Text>
      </View>
      <Button title="Logout" color="#e53935" onPress={logout} />
    </SafeAreaView>
  );
}

/* ---------------- 6-7. APP + NAVIGATION + STATE ---------------- */
export default function App() {
  const [student, setStudent] = useState(null);

  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Login">
        <Stack.Screen name="Login" options={{ headerShown: false }}>
          {props => <LoginScreen {...props} onLogin={setStudent} />}
        </Stack.Screen>
        <Stack.Screen name="Dashboard" options={{ headerBackVisible: false }}>
          {props => <DashboardScreen {...props} student={student} onLogout={() => setStudent(null)} />}
        </Stack.Screen>
        <Stack.Screen name="Attendance">
          {props => <AttendanceScreen {...props} student={student} />}
        </Stack.Screen>
        <Stack.Screen name="Profile">
          {props => <ProfileScreen {...props} student={student} onLogout={() => setStudent(null)} />}
        </Stack.Screen>
      </Stack.Navigator>
    </NavigationContainer>
  );
}

/* ---------------- 9. STYLES ---------------- */
const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: '#f5f7fa', justifyContent: 'flex-start' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center', textAlign: 'center', padding: 16 },
  title: { fontSize: 28, fontWeight: 'bold', textAlign: 'center', marginTop: 60, color: '#1e88e5' },
  subtitle: { textAlign: 'center', marginBottom: 24, color: '#666' },
  input: { backgroundColor: '#fff', borderWidth: 1, borderColor: '#ccc', borderRadius: 8, padding: 10, marginBottom: 8 },
  error: { color: '#d32f2f', marginBottom: 8 },
  card: { backgroundColor: '#fff', borderRadius: 10, padding: 14, marginBottom: 12, elevation: 2 },
  heading: { fontSize: 18, fontWeight: 'bold', marginBottom: 6 },
  line: { fontSize: 15, marginBottom: 3 },
  btn: { marginBottom: 10 },
  summary: { backgroundColor: '#1e88e5', borderRadius: 10, padding: 14, marginBottom: 12 },
  summaryText: { color: '#fff', fontSize: 20, fontWeight: 'bold' },
});
