STUDENT ATTENDANCE APP - QUICK START

FOLDER 1: attendance-api  (the backend)
  1. Open terminal in this folder
  2. npm install
  3. npm start           (keep it running)
  Test: http://localhost:3000/api/attendance/S1001
  Login: S1001 / pass123   or   S1002 / pass456

FOLDER 2: AttendanceApp  (the mobile app)
  1. Open a NEW terminal in the project folder (StudentAttendanceProject)
  2. npx create-expo-app@latest AttendanceAppRun --template blank
  3. cd AttendanceAppRun
  4. npx expo install @react-navigation/native @react-navigation/native-stack react-native-screens react-native-safe-area-context
  5. Copy AttendanceApp/App.js over AttendanceAppRun/App.js
  6. Edit BASE_URL at top of App.js (use your PC IPv4 from ipconfig, e.g. http://192.168.1.5:3000/api)
  7. npx expo start  -> scan QR with Expo Go app
