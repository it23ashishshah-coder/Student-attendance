// Mock REST API. Run: npm install express cors && node server.js
const express = require('express');
const cors = require('cors');
const app = express();
app.use(cors());
app.use(express.json());

const students = {
  S1001: { studentId: 'S1001', password: 'pass123', name: 'Aarav Sharma', email: 'aarav@college.edu', course: 'B.Tech CSE', semester: 5 },
  S1002: { studentId: 'S1002', password: 'pass456', name: 'Priya Patel', email: 'priya@college.edu', course: 'B.Sc IT', semester: 3 },
};

const attendance = {
  S1001: [
    { id: 1, subject: 'Web Technologies', attended: 34, total: 40 },
    { id: 2, subject: 'Database Systems', attended: 26, total: 40 },
    { id: 3, subject: 'Operating Systems', attended: 30, total: 38 },
    { id: 4, subject: 'Computer Networks', attended: 22, total: 36 },
    { id: 5, subject: 'Software Engineering', attended: 35, total: 38 },
  ],
  S1002: [
    { id: 1, subject: 'Python Programming', attended: 28, total: 32 },
    { id: 2, subject: 'Data Structures', attended: 20, total: 30 },
    { id: 3, subject: 'Mathematics', attended: 25, total: 30 },
  ],
};

app.post('/api/login', (req, res) => {
  const { studentId, password } = req.body;
  const s = students[studentId];
  if (!s || s.password !== password)
    return res.status(401).json({ message: 'Invalid Student ID or password' });
  const { password: _, ...student } = s;
  res.json({ student });
});

app.get('/api/attendance/:id', (req, res) => {
  const data = attendance[req.params.id];
  if (!data) return res.status(404).json({ message: 'Student not found' });
  res.json(data);
});

app.listen(3000, '0.0.0.0', () => console.log('API running on http://localhost:3000'));
